# Intro to Xv6
OSN Monsoon 2024 mini project 2

## Some pointers
- main xv6 source code is present inside `initial_xv6/src` directory. This is where you will be making all the additions/modifications necessary for the xv6 part of the Mini Project. 
- work inside the `networks/` directory for the Networking part of the Mini Project.

- You are free to delete these instructions and add your report before submitting. 