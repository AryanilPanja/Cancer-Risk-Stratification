#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define MAX 4096
#define BUF_MAX 4096
#define PORT 8080

int check_for_win(char board[4][4]){
    for (int i = 1; i < 4; i++) {
        if (board[i][1] == board[i][2] && board[i][2] == board[i][3] && board[i][1] != '.')
            return 1;
        if (board[1][i] == board[2][i] && board[2][i] == board[3][i] && board[1][i] != '.')
            return 1;
    }
    if (board[1][1] == board[2][2] && board[2][2] == board[3][3] && board[1][1] != '.')
        return 1;
    if (board[1][3] == board[2][2] && board[2][2] == board[3][1] && board[1][3] != '.')
        return 1;
    return 0;
}

int main(){
    char board[4][4];
    for(int i=0; i<4; i++){
        for(int j=0; j<4; j++){
            board[i][j] = '.';
        }
    }
    int player = 0;

    int ref_fd;
    struct sockaddr_in server_addr, client_addr1, client_addr2;
    socklen_t addr_len = sizeof(server_addr);
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);


    ref_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (ref_fd == -1) {
        printf("Socket creation error!\n");
        exit(EXIT_FAILURE);
    }
    
    if (bind(ref_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        printf("Bind error!\n");
        close(ref_fd);
        exit(EXIT_FAILURE);
    }

    // printf("Waiting for players to connect...\n");

    char buf[BUF_MAX];
    recvfrom(ref_fd, buf, BUF_MAX, 0, (struct sockaddr *)&client_addr1, &addr_len);
    printf("Player 1 connected\n");

    recvfrom(ref_fd, buf, BUF_MAX, 0, (struct sockaddr *)&client_addr2, &addr_len);
    printf("Player 2 connected\n");

    int mo = 0;
    while (mo < 9) {
        struct sockaddr_in current_client;
        if (player == 0) {
            current_client = client_addr1;
        } else {
            current_client = client_addr2;
        }

        if(mo == 0){
            printf("current board is : \n");
            for (int i = 1; i < 4; i++) {
                for (int j = 1; j < 4; j++) {
                    printf("%c ", board[i][j]);
                }
                printf("\n");
            }
            snprintf(buf, sizeof(buf), "Current board is:\n");
        for (int i = 1; i < 4; i++) {
            for (int j = 1; j < 4; j++) {
                snprintf(buf + strlen(buf), sizeof(buf) - strlen(buf), "%c ", board[i][j]);
            }
            snprintf(buf + strlen(buf), sizeof(buf) - strlen(buf), "\n");
        }
        sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&client_addr1, addr_len);
        sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&client_addr2, addr_len);
        }

        

        snprintf(buf, sizeof(buf), "Your move, enter row col: ");
        sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&current_client, addr_len);

        recvfrom(ref_fd, buf, BUF_MAX, 0, (struct sockaddr *)&current_client, &addr_len);
        int r, c;
        if (sscanf(buf, "%d %d", &r, &c) != 2 || r < 1 || r > 3 || c < 1 || c > 3 || board[r][c] != '.') {
            snprintf(buf, sizeof(buf), "Invalid move, try again!\n");
            sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&current_client, addr_len);
            continue;
        }

        if(player == 0){
            board[r][c] = 'X';
        }
        else{
            board[r][c] = 'O';
        }
        mo++;

        if (check_for_win(board)) {
            printf("winning board is : \n");
            for (int i = 1; i < 4; i++) {
                for (int j = 1; j < 4; j++) {
                    printf("%c ", board[i][j]);
                }
                printf("\n");
            }
            snprintf(buf, sizeof(buf), "Player %d wins!\n", player + 1);
            printf("Player %d wins!\n", player + 1);
            sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&client_addr1, addr_len);
            sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&client_addr2, addr_len);
            break;
        }

        printf("Updated board is : \n");
            for (int i = 1; i < 4; i++) {
                for (int j = 1; j < 4; j++) {
                    printf("%c ", board[i][j]);
                }
                printf("\n");
            }

        snprintf(buf, sizeof(buf), "Updated board is:\n");
        for (int i = 1; i < 4; i++) {
            for (int j = 1; j < 4; j++) {
                snprintf(buf + strlen(buf), sizeof(buf) - strlen(buf), "%c ", board[i][j]);
            }
            snprintf(buf + strlen(buf), sizeof(buf) - strlen(buf), "\n");
        }
        sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&client_addr1, addr_len);
        sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&client_addr2, addr_len);

        if(player == 0){
            player = 1;
        }
        else{
            player = 0;
        }
    }

    if (mo == 9) {
        snprintf(buf, sizeof(buf), "It's a draw!\n");
        printf("It's a draw!\n");
        sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&client_addr1, addr_len);
        sendto(ref_fd, buf, strlen(buf), 0, (struct sockaddr *)&client_addr2, addr_len);
    }

    close(ref_fd);
    return 0;
}
